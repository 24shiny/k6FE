document.addEventListener("DOMContentLoaded", () => {
    const btg = document.querySelector("#bttGenerator");
    const btts = document.querySelectorAll("button");
    let randArr = [];
    let ranN;
    
    btg.addEventListener("click",()=>{
        // generate numbers
        while(randArr.length<8){
        ranN = Math.floor(Math.random() * 45) + 1;
        for(s of randArr){
            if(s!=ranN) {
                randArr.push(ranN);
                return;
            }
        }
        }
        console.log(randArr);
        // the numbers apper in the buttons
        btts.forEach((item)=>{
            // item.setAttribute()
            document.querySelector(item).innerHTML = "number.."
        })
    });

});